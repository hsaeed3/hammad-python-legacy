from .dynamic import DynamicInputInteractions, StaticInputInteractions
from .static import MessageStyles, Message