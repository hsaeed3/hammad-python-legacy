from .classification import Classification
from .regression import Regression
from .clustering import Clustering